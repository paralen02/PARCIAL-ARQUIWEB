package com.example.api_examen_parcial_202115142_v2.serviceinterfaces;

import com.example.api_examen_parcial_202115142_v2.entities.University;

import java.util.List;

public interface IUniversityService {
    void insert(University eapmUniversity);

    void delete(int eapmIdUniversity);

    University listId(int eapmIdUniversity);

    List<University> list();
    void update(University eapmUniversity);

}
