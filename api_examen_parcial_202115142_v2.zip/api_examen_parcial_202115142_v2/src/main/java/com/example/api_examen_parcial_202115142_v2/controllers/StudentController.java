package com.example.api_examen_parcial_202115142_v2.controllers;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import com.example.api_examen_parcial_202115142_v2.dtos.StudentDTO;
import com.example.api_examen_parcial_202115142_v2.entities.Student;
import com.example.api_examen_parcial_202115142_v2.serviceinterfaces.IStudentService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/student")
public class StudentController {
    @Autowired
    private IStudentService eapmMyService;

    @PostMapping
    @PreAuthorize("hasAuthority('ADMINISTRATOR')")
    public void registrar(@RequestBody StudentDTO eapmDto) {
        ModelMapper eapmM = new ModelMapper();
        Student eapmMyItem = eapmM.map(eapmDto, Student.class);
        eapmMyService.insert(eapmMyItem);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id")Integer eapmIdStudent){
        eapmMyService.delete(eapmIdStudent);
    }

    @GetMapping("/{id}")
    public StudentDTO listarId(@PathVariable("id")Integer eapmIdStudent){
        ModelMapper eapmM = new ModelMapper();
        StudentDTO eapmMyItem = eapmM.map(eapmMyService.listId(eapmIdStudent), StudentDTO.class);
        return eapmMyItem;
    }

    @GetMapping
    public List<StudentDTO> listar(){
        return eapmMyService.list().stream().map(x -> {
            ModelMapper eapmM = new ModelMapper();
            return eapmM.map(x, StudentDTO.class);
        }).collect(Collectors.toList());
    }

    @PutMapping
    public void modificar(@RequestBody Student eapmDto) {
        ModelMapper eapmM = new ModelMapper();
        Student eapmD = eapmM.map(eapmDto, Student.class);
        eapmMyService.insert(eapmD);
    }

    @GetMapping("/university/{id}")
    public List<String[]> listStudentsByUniversityId(@PathVariable("id") Long universityId) {
        return eapmMyService.listStudentsByUniversityId(universityId);
    }
    @GetMapping("/grade/{qualification}")
    public List<String[]> listStudentsByGrade(@PathVariable("qualification") Double qualification) {
        return eapmMyService.listStudentsByGrade(qualification);
    }
}
