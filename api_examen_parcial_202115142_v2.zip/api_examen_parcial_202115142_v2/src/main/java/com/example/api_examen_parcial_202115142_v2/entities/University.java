package com.example.api_examen_parcial_202115142_v2.entities;

import javax.persistence.*;
@Entity
@Table(name ="University" )
public class University {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int eapmId;
    @Column(name = "name",nullable = false,length = 40)
    private String eapmName;
    @Column(name = "address",nullable = false,length = 40)
    private String eapmAdress;
    @Column(name = "email",nullable = false,length = 40)
    private String eapmEmail;

    public University() {
    }

    public University(int eapmId, String eapmName, String eapmAdress, String eapmEmail) {
        this.eapmId = eapmId;
        this.eapmName = eapmName;
        this.eapmAdress = eapmAdress;
        this.eapmEmail = eapmEmail;
    }

    public int getEapmId() {
        return eapmId;
    }

    public void setEapmId(int eapmId) {
        this.eapmId = eapmId;
    }

    public String getEapmName() {
        return eapmName;
    }

    public void setEapmName(String eapmName) {
        this.eapmName = eapmName;
    }

    public String getEapmAdress() {
        return eapmAdress;
    }

    public void setEapmAdress(String eapmAdress) {
        this.eapmAdress = eapmAdress;
    }

    public String getEapmEmail() {
        return eapmEmail;
    }

    public void setEapmEmail(String eapmEmail) {
        this.eapmEmail = eapmEmail;
    }
}
