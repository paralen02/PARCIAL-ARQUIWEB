package com.example.api_examen_parcial_202115142_v2.dtos;

import javax.persistence.Column;

public class UniversityDTO {
    private int eapmId;
    private String eapmName;
    private String eapmAdress;
    private String eapmEmail;

    public int getEapmId() {
        return eapmId;
    }

    public void setEapmId(int eapmId) {
        this.eapmId = eapmId;
    }

    public String getEapmName() {
        return eapmName;
    }

    public void setEapmName(String eapmName) {
        this.eapmName = eapmName;
    }

    public String getEapmAdress() {
        return eapmAdress;
    }

    public void setEapmAdress(String eapmAdress) {
        this.eapmAdress = eapmAdress;
    }

    public String getEapmEmail() {
        return eapmEmail;
    }

    public void setEapmEmail(String eapmEmail) {
        this.eapmEmail = eapmEmail;
    }
}
