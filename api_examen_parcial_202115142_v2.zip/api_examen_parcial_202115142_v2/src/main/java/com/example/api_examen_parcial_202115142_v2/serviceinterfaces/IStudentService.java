package com.example.api_examen_parcial_202115142_v2.serviceinterfaces;

import com.example.api_examen_parcial_202115142_v2.entities.Student;

import java.util.List;

public interface IStudentService {
    void insert(Student eapmStudent);

    void delete(int eapmIdStudent);

    Student listId(int eapmIdStudent);

    List<Student> list();
    void update(Student eapmStudent);

    public List<String[]> listStudentsByUniversityId(Long universityId);
    public List<String[]> listStudentsByGrade(Double qualification);

}
