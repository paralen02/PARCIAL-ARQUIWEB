package com.example.api_examen_parcial_202115142_v2.serviceimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.api_examen_parcial_202115142_v2.entities.University;
import com.example.api_examen_parcial_202115142_v2.repositories.IUniversityRepository;
import com.example.api_examen_parcial_202115142_v2.serviceinterfaces.IUniversityService;

import java.util.List;

@Service
public class UniversityServiceImplement implements IUniversityService {
    @Autowired
    private IUniversityRepository eapmMyRepository;
    @Override
    public void insert(University eapmUniversity) {
        eapmMyRepository.save(eapmUniversity);
    }

    @Override
    public void delete(int eapmUniversity) {
        eapmMyRepository.deleteById(eapmUniversity);
    }

    @Override
    public University listId(int eapmIdUniversity) {
        return eapmMyRepository.findById(eapmIdUniversity).orElse(new University());
    }

    @Override
    public List<University> list() {
        return eapmMyRepository.findAll();
    }

    @Override
    public void update(University eapmUniversity) {
        eapmMyRepository.save(eapmUniversity);
    }

}