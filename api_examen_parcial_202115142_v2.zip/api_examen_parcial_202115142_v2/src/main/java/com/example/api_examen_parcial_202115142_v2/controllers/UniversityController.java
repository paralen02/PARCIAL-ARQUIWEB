package com.example.api_examen_parcial_202115142_v2.controllers;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import com.example.api_examen_parcial_202115142_v2.dtos.UniversityDTO;
import com.example.api_examen_parcial_202115142_v2.entities.University;
import com.example.api_examen_parcial_202115142_v2.serviceinterfaces.IUniversityService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/universities")
public class UniversityController {
    @Autowired
    private IUniversityService eapmMyService;

    @PostMapping
    @PreAuthorize("hasAuthority('ADMINISTRATOR')")
    public void registrar(@RequestBody UniversityDTO eapmDto) {
        ModelMapper eapmM = new ModelMapper();
        University eapmMyItem = eapmM.map(eapmDto, University.class);
        eapmMyService.insert(eapmMyItem);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id")Integer eapmIdUniversity){
        eapmMyService.delete(eapmIdUniversity);
    }

    @GetMapping("/{id}")
    public UniversityDTO listarId(@PathVariable("id")Integer eapmIdUniversity){
        ModelMapper eapmM = new ModelMapper();
        UniversityDTO eapmMyItem = eapmM.map(eapmMyService.listId(eapmIdUniversity), UniversityDTO.class);
        return eapmMyItem;
    }

    @GetMapping
    public List<UniversityDTO> listar(){
        return eapmMyService.list().stream().map(x -> {
            ModelMapper eapmM = new ModelMapper();
            return eapmM.map(x, UniversityDTO.class);
        }).collect(Collectors.toList());
    }

    @PutMapping
    public void modificar(@RequestBody University eapmDto) {
        ModelMapper eapmM = new ModelMapper();
        University eapmD = eapmM.map(eapmDto, University.class);
        eapmMyService.insert(eapmD);
    }
}