package com.example.api_examen_parcial_202115142_v2.serviceimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.api_examen_parcial_202115142_v2.entities.Student;
import com.example.api_examen_parcial_202115142_v2.repositories.IStudentRepository;
import com.example.api_examen_parcial_202115142_v2.serviceinterfaces.IStudentService;

import java.util.List;

@Service
public class StudentServiceImplement implements IStudentService {
    @Autowired
    private IStudentRepository eapmMyRepository;
    @Override
    public void insert(Student eapmStudent) {
        eapmMyRepository.save(eapmStudent);
    }

    @Override
    public void delete(int eapmStudent) {
        eapmMyRepository.deleteById(eapmStudent);
    }

    @Override
    public Student listId(int eapmIdStudent) {
        return eapmMyRepository.findById(eapmIdStudent).orElse(new Student());
    }

    @Override
    public List<Student> list() {
        return eapmMyRepository.findAll();
    }

    @Override
    public void update(Student eapmStudent) {
        eapmMyRepository.save(eapmStudent);
    }

    @Override
    public List<String[]> listStudentsByUniversityId(Long universityId) {
        return eapmMyRepository.listStudentsByUniversityId(universityId);
    }
    @Override
    public List<String[]> listStudentsByGrade(Double qualification) {
        return eapmMyRepository.listStudentsByGrade(qualification);
    }

}
