package com.example.api_examen_parcial_202115142_v2.repositories;

import com.example.api_examen_parcial_202115142_v2.entities.Student;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IStudentRepository extends JpaRepository<Student, Integer> {
    @Query(value = "SELECT s.code AS Code, s.name AS Name, s.weighted_average AS WeightedAverage\n" +
            "FROM student s\n" +
            "JOIN university u ON s.id_university = u.eapm_id\n" +
            "WHERE u.eapm_id = :universityId\n" +
            "ORDER BY s.name", nativeQuery = true)

    public List<String[]> listStudentsByUniversityId(@Param("universityId") Long universityId);

    @Query(value = "SELECT s.name AS Estudiante\n" +
            "FROM student s\n" +
            "WHERE s.weighted_average >= :qualification\n" +
            "ORDER BY s.name", nativeQuery = true)
    public List<String[]> listStudentsByGrade(@Param("qualification") Double qualification);

}