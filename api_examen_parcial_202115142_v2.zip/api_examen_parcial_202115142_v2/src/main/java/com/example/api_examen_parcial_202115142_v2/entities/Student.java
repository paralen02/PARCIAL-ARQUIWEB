package com.example.api_examen_parcial_202115142_v2.entities;

import javax.persistence.*;

@Entity
@Table(name ="Student" )
public class Student {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long eapmId;
    @Column(name = "code",nullable = false,length = 40, unique = true)
    private String eapmCode;
    @Column(name = "name",nullable = false,length = 40)
    private String eapmName;
    @Column(name = "weightedAverage",nullable = false)
    private double eapmWeightedAverage;
    @ManyToOne
    @JoinColumn(name = "idUniversity")
    private University eapmUniversity;

    public Student() {
    }

    public Student(Long eapmId, String eapmCode, String eapmName, double eapmWeightedAverage, University eapmUniversity) {
        this.eapmId = eapmId;
        this.eapmCode = eapmCode;
        this.eapmName = eapmName;
        this.eapmWeightedAverage = eapmWeightedAverage;
        this.eapmUniversity = eapmUniversity;
    }

    public Long getEapmId() {
        return eapmId;
    }

    public void setEapmId(Long eapmId) {
        this.eapmId = eapmId;
    }

    public String getEapmCode() {
        return eapmCode;
    }

    public void setEapmCode(String eapmCode) {
        this.eapmCode = eapmCode;
    }

    public String getEapmName() {
        return eapmName;
    }

    public void setEapmName(String eapmName) {
        this.eapmName = eapmName;
    }

    public double getEapmWeightedAverage() {
        return eapmWeightedAverage;
    }

    public void setEapmWeightedAverage(double eapmWeightedAverage) {
        this.eapmWeightedAverage = eapmWeightedAverage;
    }

    public University getEapmUniversity() {
        return eapmUniversity;
    }

    public void setEapmUniversity(University eapmUniversity) {
        this.eapmUniversity = eapmUniversity;
    }
}
