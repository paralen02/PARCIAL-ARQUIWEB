package com.example.api_examen_parcial_202115142_v2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiExamenParcial202115142V2ApplicationTests {

    @Test
    void contextLoads() {
    }

}
