package com.example.api_examen_parcial_202115142_v1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApiExamenParcial202115142V1Application {

    public static void main(String[] eapmArgs) {
        SpringApplication.run(ApiExamenParcial202115142V1Application.class, eapmArgs);
    }

}
