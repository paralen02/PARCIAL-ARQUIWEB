package com.example.api_examen_parcial_202115142_v1;

import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

public class ServletInitializer extends SpringBootServletInitializer {

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder eapmApplication) {
        return eapmApplication.sources(ApiExamenParcial202115142V1Application.class);
    }

}
