package com.example.api_examen_parcial_202115142_v1.controllers;

import com.example.api_examen_parcial_202115142_v1.dtos.IngredientDTO;
import com.example.api_examen_parcial_202115142_v1.entities.Ingredient;
import com.example.api_examen_parcial_202115142_v1.serviceinterfaces.IIngredientService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/ingredients")
public class IngredientController {
    @Autowired
    private IIngredientService eapmMyService;

    @PostMapping
    @PreAuthorize("hasAuthority('COCINERO')")
    public void registrar(@RequestBody IngredientDTO eapmDto) {
        ModelMapper eapmM = new ModelMapper();
        Ingredient eapmMyItem = eapmM.map(eapmDto, Ingredient.class);
        eapmMyService.insert(eapmMyItem);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id")Integer eapmIdIngredient){
        eapmMyService.delete(eapmIdIngredient);
    }

    @GetMapping("/{id}")
    public IngredientDTO listarId(@PathVariable("id")Integer eapmIdIngredient){
        ModelMapper eapmM = new ModelMapper();
        IngredientDTO eapmMyItem = eapmM.map(eapmMyService.listId(eapmIdIngredient), IngredientDTO.class);
        return eapmMyItem;
    }

    @GetMapping
    public List<IngredientDTO> listar(){
        return eapmMyService.list().stream().map(x -> {
            ModelMapper eapmM = new ModelMapper();
            return eapmM.map(x, IngredientDTO.class);
        }).collect(Collectors.toList());
    }

    @PutMapping
    public void modificar(@RequestBody Ingredient eapmDto) {
        ModelMapper eapmM = new ModelMapper();
        Ingredient eapmI = eapmM.map(eapmDto, Ingredient.class);
        eapmMyService.insert(eapmI);
    }
}