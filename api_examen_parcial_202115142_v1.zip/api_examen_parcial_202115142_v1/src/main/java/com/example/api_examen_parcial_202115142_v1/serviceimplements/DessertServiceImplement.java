package com.example.api_examen_parcial_202115142_v1.serviceimplements;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.example.api_examen_parcial_202115142_v1.entities.Dessert;
import com.example.api_examen_parcial_202115142_v1.repositories.IDessertRepository;
import com.example.api_examen_parcial_202115142_v1.serviceinterfaces.IDessertService;

import java.util.List;

@Service
public class DessertServiceImplement implements IDessertService {
    @Autowired
    private IDessertRepository eapmMyRepository;
    @Override
    public void insert(Dessert eapmDessert) {
        eapmMyRepository.save(eapmDessert);
    }

    @Override
    public void delete(int eapmDessert) {
        eapmMyRepository.deleteById(eapmDessert);
    }

    @Override
    public Dessert listId(int eapmIdDessert) {
        return eapmMyRepository.findById(eapmIdDessert).orElse(new Dessert());
    }

    @Override
    public List<Dessert> list() {
        return eapmMyRepository.findAll();
    }

    @Override
    public void update(Dessert eapmDessert) {
        eapmMyRepository.save(eapmDessert);
    }

    @Override
    public List<String[]> countIngredientsByDifficulty() {
        return eapmMyRepository.countIngredientsByDifficulty();
    }

    public List<String[]> listIngredientsByCategory() {
        return eapmMyRepository.listIngredientsByCategory();
    }

}
