package com.example.api_examen_parcial_202115142_v1.entities;

import javax.persistence.*;
import java.time.LocalDate;
@Entity
@Table(name ="Dessert" )
public class Dessert {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int eapmIdDessert;
    @Column(name = "nameDessert",nullable = false,length = 40)
    private String eapmNameDessert;
    @Column(name = "preparationTimeDessert",nullable = false)
    private int eapmPreparationTimeDessert;
    @Column(name = "difficultyDessert",nullable = false,length = 20)
    private String eapmDifficultyDessert;
    @Column(name = "categoryDessert",nullable = false,length = 20)
    private String eapmCategoryDessert;

    public Dessert() {
    }

    public Dessert(int eapmIdDessert, String eapmNameDessert, int eapmPreparationTimeDessert, String eapmDifficultyDessert, String eapmCategoryDessert) {
        this.eapmIdDessert = eapmIdDessert;
        this.eapmNameDessert = eapmNameDessert;
        this.eapmPreparationTimeDessert = eapmPreparationTimeDessert;
        this.eapmDifficultyDessert = eapmDifficultyDessert;
        this.eapmCategoryDessert = eapmCategoryDessert;
    }

    public int getEapmIdDessert() {
        return eapmIdDessert;
    }

    public void setEapmIdDessert(int eapmIdDessert) {
        this.eapmIdDessert = eapmIdDessert;
    }

    public String getEapmNameDessert() {
        return eapmNameDessert;
    }

    public void setEapmNameDessert(String eapmNameDessert) {
        this.eapmNameDessert = eapmNameDessert;
    }

    public int getEapmPreparationTimeDessert() {
        return eapmPreparationTimeDessert;
    }

    public void setEapmPreparationTimeDessert(int eapmPreparationTimeDessert) {
        this.eapmPreparationTimeDessert = eapmPreparationTimeDessert;
    }

    public String getEapmDifficultyDessert() {
        return eapmDifficultyDessert;
    }

    public void setEapmDifficultyDessert(String eapmDifficultyDessert) {
        this.eapmDifficultyDessert = eapmDifficultyDessert;
    }

    public String getEapmCategoryDessert() {
        return eapmCategoryDessert;
    }

    public void setEapmCategoryDessert(String eapmCategoryDessert) {
        this.eapmCategoryDessert = eapmCategoryDessert;
    }
}