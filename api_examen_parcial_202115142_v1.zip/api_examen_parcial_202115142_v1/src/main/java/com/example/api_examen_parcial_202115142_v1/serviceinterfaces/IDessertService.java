package com.example.api_examen_parcial_202115142_v1.serviceinterfaces;

import com.example.api_examen_parcial_202115142_v1.entities.Dessert;

import java.util.List;

public interface IDessertService {
    void insert(Dessert eapmDessert);

    void delete(int eapmIdDessert);

    Dessert listId(int eapmIdDessert);

    List<Dessert> list();
    void update(Dessert eapmDessert);

    List<String[]> countIngredientsByDifficulty();
    List<String[]> listIngredientsByCategory();

}