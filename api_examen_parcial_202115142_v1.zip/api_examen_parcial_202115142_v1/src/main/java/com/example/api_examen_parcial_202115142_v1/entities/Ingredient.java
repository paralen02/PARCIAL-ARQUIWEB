package com.example.api_examen_parcial_202115142_v1.entities;
import javax.persistence.*;

@Entity
@Table(name = "Ingredient")
public class Ingredient {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int eapmIdIngredient;
    @Column(name = "nameIngredient", nullable = false, length = 30)
    private String eapmNameIngredient;
    @Column(name = "quantityIngredient", nullable = false)
    private double eapmQuantityIngredient;
    @ManyToOne
    @JoinColumn(name = "idDessert")
    private Dessert eapmDessert;

    public Ingredient() {
    }

    public Ingredient(int eapmIdIngredient, String eapmNameIngredient, double eapmQuantityIngredient, Dessert eapmDessert) {
        this.eapmIdIngredient = eapmIdIngredient;
        this.eapmNameIngredient = eapmNameIngredient;
        this.eapmQuantityIngredient = eapmQuantityIngredient;
        this.eapmDessert = eapmDessert;
    }

    public int getEapmIdIngredient() {
        return eapmIdIngredient;
    }

    public void setEapmIdIngredient(int eapmIdIngredient) {
        this.eapmIdIngredient = eapmIdIngredient;
    }

    public String getEapmNameIngredient() {
        return eapmNameIngredient;
    }

    public void setEapmNameIngredient(String eapmNameIngredient) {
        this.eapmNameIngredient = eapmNameIngredient;
    }

    public double getEapmQuantityIngredient() {
        return eapmQuantityIngredient;
    }

    public void setEapmQuantityIngredient(double eapmQuantityIngredient) {
        this.eapmQuantityIngredient = eapmQuantityIngredient;
    }

    public Dessert getEapmDessert() {
        return eapmDessert;
    }

    public void setEapmDessert(Dessert eapmDessert) {
        this.eapmDessert = eapmDessert;
    }
}