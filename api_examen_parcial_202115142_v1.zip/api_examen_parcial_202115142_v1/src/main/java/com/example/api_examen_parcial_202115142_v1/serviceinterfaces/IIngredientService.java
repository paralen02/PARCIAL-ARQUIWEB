package com.example.api_examen_parcial_202115142_v1.serviceinterfaces;

import com.example.api_examen_parcial_202115142_v1.entities.Ingredient;
import com.example.api_examen_parcial_202115142_v1.entities.Ingredient;

import java.util.List;

public interface IIngredientService {
    void insert(Ingredient eapmIngredient);

    void delete(int eapmIdIngredient);

    Ingredient listId(int eapmIdIngredient);

    List<Ingredient> list();
    void update(Ingredient eapmIngredient);
}