package com.example.api_examen_parcial_202115142_v1.dtos;

import com.example.api_examen_parcial_202115142_v1.entities.Dessert;

public class IngredientDTO {
    private int eapmIdIngredient;
    private String eapmNameIngredient;
    private double eapmQuantityIngredient;
    private Dessert eapmDessert;

    public int getEapmIdIngredient() {
        return eapmIdIngredient;
    }

    public void setEapmIdIngredient(int eapmIdIngredient) {
        this.eapmIdIngredient = eapmIdIngredient;
    }

    public String getEapmNameIngredient() {
        return eapmNameIngredient;
    }

    public void setEapmNameIngredient(String eapmNameIngredient) {
        this.eapmNameIngredient = eapmNameIngredient;
    }

    public double getEapmQuantityIngredient() {
        return eapmQuantityIngredient;
    }

    public void setEapmQuantityIngredient(double eapmQuantityIngredient) {
        this.eapmQuantityIngredient = eapmQuantityIngredient;
    }

    public Dessert getEapmDessert() {
        return eapmDessert;
    }

    public void setEapmDessert(Dessert eapmDessert) {
        this.eapmDessert = eapmDessert;
    }
}
