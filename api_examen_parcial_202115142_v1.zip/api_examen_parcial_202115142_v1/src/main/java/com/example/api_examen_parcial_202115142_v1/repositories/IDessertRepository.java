package com.example.api_examen_parcial_202115142_v1.repositories;

import com.example.api_examen_parcial_202115142_v1.entities.Dessert;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface IDessertRepository extends JpaRepository<Dessert, Integer> {
    @Query(value = "SELECT d.difficulty_dessert AS Difficulty, COUNT(i.eapm_id_ingredient) AS Ingredients\n" +
            "FROM dessert d\n" +
            "JOIN ingredient i ON d.eapm_id_dessert = i.id_dessert\n" +
            "GROUP BY d.difficulty_dessert\n" +
            "ORDER BY d.difficulty_dessert", nativeQuery = true)

    public List<String[]> countIngredientsByDifficulty();

    @Query(value = "SELECT d.category_dessert AS Category, i.name_ingredient AS Ingredient\n" +
            "FROM dessert d\n" +
            "JOIN ingredient i ON d.eapm_id_dessert = i.id_dessert\n" +
            "GROUP BY d.category_dessert, i.name_ingredient\n" +
            "ORDER BY d.category_dessert, i.name_ingredient", nativeQuery = true)

    public List<String[]> listIngredientsByCategory();
}
