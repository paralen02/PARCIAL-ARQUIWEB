package com.example.api_examen_parcial_202115142_v1.serviceimplements;

import com.example.api_examen_parcial_202115142_v1.entities.Ingredient;
import com.example.api_examen_parcial_202115142_v1.repositories.IIngredientRepository;
import com.example.api_examen_parcial_202115142_v1.serviceinterfaces.IIngredientService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IngredientServiceImplement implements IIngredientService {
    @Autowired
    private IIngredientRepository eapmMyRepository;
    @Override
    public void insert(Ingredient eapmIngredient) {
        eapmMyRepository.save(eapmIngredient);
    }

    @Override
    public void delete(int eapmIngredient) {
        eapmMyRepository.deleteById(eapmIngredient);
    }

    @Override
    public Ingredient listId(int eapmIdIngredient) {
        return eapmMyRepository.findById(eapmIdIngredient).orElse(new Ingredient());
    }

    @Override
    public List<Ingredient> list() {
        return eapmMyRepository.findAll();
    }

    @Override
    public void update(Ingredient eapmIngredient) {
        eapmMyRepository.save(eapmIngredient);
    }
}
