package com.example.api_examen_parcial_202115142_v1.controllers;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import com.example.api_examen_parcial_202115142_v1.dtos.DessertDTO;
import com.example.api_examen_parcial_202115142_v1.entities.Dessert;
import com.example.api_examen_parcial_202115142_v1.serviceinterfaces.IDessertService;

import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/desserts")
public class DessertController {
    @Autowired
    private IDessertService eapmMyService;

    @PostMapping
    @PreAuthorize("hasAuthority('ASISTENTE')")
    public void registrar(@RequestBody DessertDTO eapmDto) {
        ModelMapper eapmM = new ModelMapper();
        Dessert eapmMyItem = eapmM.map(eapmDto, Dessert.class);
        eapmMyService.insert(eapmMyItem);
    }

    @DeleteMapping("/{id}")
    public void eliminar(@PathVariable("id")Integer eapmIdDessert){
        eapmMyService.delete(eapmIdDessert);
    }

    @GetMapping("/{id}")
    public DessertDTO listarId(@PathVariable("id")Integer eapmIdDessert){
        ModelMapper eapmM = new ModelMapper();
        DessertDTO eapmMyItem = eapmM.map(eapmMyService.listId(eapmIdDessert), DessertDTO.class);
        return eapmMyItem;
    }

    @GetMapping
    public List<DessertDTO> listar(){
        return eapmMyService.list().stream().map(x -> {
            ModelMapper eapmM = new ModelMapper();
            return eapmM.map(x, DessertDTO.class);
        }).collect(Collectors.toList());
    }

    @PutMapping
    public void modificar(@RequestBody Dessert eapmDto) {
        ModelMapper eapmM = new ModelMapper();
        Dessert eapmD = eapmM.map(eapmDto, Dessert.class);
        eapmMyService.insert(eapmD);
    }

    @GetMapping("/count")
    @PreAuthorize("hasAuthority('COCINERO')")
    public List<String[]> countIngredientsByDifficulty() {
        return eapmMyService.countIngredientsByDifficulty();
    }

    @GetMapping("/category")
    @PreAuthorize("hasAuthority('COCINERO')")
    public List<String[]> listIngredientsByCategory() {
        return eapmMyService.listIngredientsByCategory();
    }
}
