package com.example.api_examen_parcial_202115142_v1.dtos;
public class DessertDTO {
    private int eapmIdDessert;
    private String eapmNameDessert;
    private int eapmPreparationTimeDessert;
    private String eapmDifficultyDessert;
    private String eapmCategoryDessert;

    public String getEapmCategoryDessert() {
        return eapmCategoryDessert;
    }

    public void setEapmCategoryDessert(String eapmCategoryDessert) {
        this.eapmCategoryDessert = eapmCategoryDessert;
    }

    public int getEapmIdDessert() {
        return eapmIdDessert;
    }

    public void setEapmIdDessert(int eapmIdDessert) {
        this.eapmIdDessert = eapmIdDessert;
    }

    public String getEapmNameDessert() {
        return eapmNameDessert;
    }

    public void setEapmNameDessert(String eapmNameDessert) {
        this.eapmNameDessert = eapmNameDessert;
    }

    public int getEapmPreparationTimeDessert() {
        return eapmPreparationTimeDessert;
    }

    public void setEapmPreparationTimeDessert(int eapmPreparationTimeDessert) {
        this.eapmPreparationTimeDessert = eapmPreparationTimeDessert;
    }

    public String getEapmDifficultyDessert() {
        return eapmDifficultyDessert;
    }

    public void setEapmDifficultyDessert(String eapmDifficultyDessert) {
        this.eapmDifficultyDessert = eapmDifficultyDessert;
    }
}
