package com.example.codigosecurity;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CodigoSecurityApplicationTests {

	@Test
	void contextLoads() {
	}

}
