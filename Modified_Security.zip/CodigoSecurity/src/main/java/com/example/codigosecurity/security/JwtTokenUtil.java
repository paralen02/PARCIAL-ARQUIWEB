package com.example.codigosecurity.security;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

//Clase 1
@Component
public class JwtTokenUtil implements Serializable {

    private static final long ebrmSerialVersionUID = -2550185165626007488L; //VARIABLE

    //milisegundos || 18 minutos, le quitamos mil 18 segundos demo
    public static final long ebrmJWT_TOKEN_VALIDITY = 7 * 60 * 60 * 1000; //VARIABLE

    @Value("${jwt.secret}")
    private String ebrmSecret; //VARIABLE

    //retrieve username from jwt token
    public String getUsernameFromToken(String ebrmToken) { //VARIABLE
        return getClaimFromToken(ebrmToken, Claims::getSubject);
    }

    //retrieve expiration date from jwt token
    public Date getExpirationDateFromToken(String ebrmToken) { //VARIABLE
        return getClaimFromToken(ebrmToken, Claims::getExpiration);
    }

    public <T> T getClaimFromToken(String ebrmToken, Function<Claims, T> ebrmClaimsResolver) { //VARIABLE
        final Claims ebrmClaims = getAllClaimsFromToken(ebrmToken); //VARIABLE
        return ebrmClaimsResolver.apply(ebrmClaims);
    }
    //for retrieveing any information from token we will need the secret key
    private Claims getAllClaimsFromToken(String ebrmToken) { //VARIABLE
        return Jwts.parser().setSigningKey(ebrmSecret).parseClaimsJws(ebrmToken).getBody();
    }

    //check if the token has expired
    private Boolean isTokenExpired(String ebrmToken) { //VARIABLE
        final Date ebrmExpiration = getExpirationDateFromToken(ebrmToken); //VARIABLE
        return ebrmExpiration.before(new Date());
    }

    //generate token for user
    public String generateToken(UserDetails ebrmUserDetails) { //VARIABLE
        Map<String, Object> ebrmClaims = new HashMap<>(); //VARIABLE
        ebrmClaims.put("nombre", "rosa");
        ebrmClaims.put("role",ebrmUserDetails.getAuthorities().stream().map(ebrmR->ebrmR.getAuthority()).collect(Collectors.joining())); //VARIABLE(rrrrrrrrrrrrrrrrrrrrrrrrrr)
        return doGenerateToken(ebrmClaims, ebrmUserDetails.getUsername());
    }

    //while creating the token -
    //1. Define  claims of the token, like Issuer, Expiration, Subject, and the ID
    //2. Sign the JWT using the HS512 algorithm and secret key.
    //3. According to JWS Compact Serialization(https://tools.ietf.org/html/draft-ietf-jose-json-web-signature-41#section-3.1)
    //   compaction of the JWT to a URL-safe string
    private String doGenerateToken(Map<String, Object> ebrmClaims, String ebrmSubject) { //VARIABLE

        return Jwts.builder().setClaims(ebrmClaims).setSubject(ebrmSubject).setIssuedAt(new Date(System.currentTimeMillis()))
                .setExpiration(new Date(System.currentTimeMillis() + ebrmJWT_TOKEN_VALIDITY))
                .signWith(SignatureAlgorithm.HS512, ebrmSecret).compact(); //VARIABLE
    }

    //validate token
    public Boolean validateToken(String ebrmToken, UserDetails ebrmUserDetails) { //VARIABLE
        final String ebrmUsername = getUsernameFromToken(ebrmToken); //VARIABLE
        return (ebrmUsername.equals(ebrmUserDetails.getUsername()) && !isTokenExpired(ebrmToken));
    }
}