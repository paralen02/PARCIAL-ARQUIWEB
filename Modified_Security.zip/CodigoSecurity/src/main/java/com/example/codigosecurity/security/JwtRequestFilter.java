package com.example.codigosecurity.security;

import com.example.codigosecurity.serviceimplements.JwtUserDetailsService;
import io.jsonwebtoken.ExpiredJwtException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


//Clase 6
@Component
public class JwtRequestFilter extends OncePerRequestFilter {
	@Autowired
	private JwtUserDetailsService ebrmJwtUserDetailsService; //VARIABLE
	@Autowired
	private JwtTokenUtil ebrmJwtTokenUtil; //VARIABLE
	@Override
	protected void doFilterInternal(HttpServletRequest ebrmRequest, HttpServletResponse ebrmResponse, FilterChain ebrmChain) //VARIABLE
			throws ServletException, IOException {
		final String ebrmRequestTokenHeader = ebrmRequest.getHeader("Authorization"); //VARIABLE
		String ebrmUsername = null; //VARIABLE
		String ebrmJwtToken = null; //VARIABLE
		// JWT Token is in the form "Bearer token". Remove Bearer word and get
		// only the Token
		if (ebrmRequestTokenHeader != null && ebrmRequestTokenHeader.startsWith("Bearer ")) {
			//jwtToken = requestTokenHeader.substring(7);
			ebrmJwtToken = ebrmRequestTokenHeader.split(" ")[1].trim(); //VARIABLE

			try {
				ebrmUsername = ebrmJwtTokenUtil.getUsernameFromToken(ebrmJwtToken); //VARIABLE
			} catch (IllegalArgumentException ebrmE) { //VARIABLE
				System.out.println("No se puede encontrar el token JWT");
			} catch (ExpiredJwtException ebrmE) { //VARIABLE
				System.out.println("Token JWT ha expirado");
			}
		} else {
			logger.warn("JWT Token no inicia con la palabra Bearer");
		}

		// Once we get the token validate it.
		if (ebrmUsername != null && SecurityContextHolder.getContext().getAuthentication() == null) {

			UserDetails ebrmUserDetails = this.ebrmJwtUserDetailsService.loadUserByUsername(ebrmUsername); //VARIABLE

			// if token is valid configure Spring Security to manually set
			// authentication
			if (ebrmJwtTokenUtil.validateToken(ebrmJwtToken, ebrmUserDetails)) {

				UsernamePasswordAuthenticationToken usernamePasswordAuthenticationToken = new UsernamePasswordAuthenticationToken(//VARIABLE
						ebrmUserDetails, null, ebrmUserDetails.getAuthorities());
				usernamePasswordAuthenticationToken
						.setDetails(new WebAuthenticationDetailsSource().buildDetails(ebrmRequest));
				// After setting the Authentication in the context, we specify
				// that the current user is authenticated. So it passes the
				// Spring Security Configurations successfully.
				SecurityContextHolder.getContext().setAuthentication(usernamePasswordAuthenticationToken);
			}
		}
				ebrmChain.doFilter(ebrmRequest, ebrmResponse);
	}
}
