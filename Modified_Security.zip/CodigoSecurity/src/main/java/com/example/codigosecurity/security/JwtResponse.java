package com.example.codigosecurity.security;
import java.io.Serializable;

/*
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.io.Serializable;

clase 5
@AllArgsConstructor
@Getter*/
public class JwtResponse implements Serializable {

	private static final long ebrmSerialVersionUID = -8091879091924046844L; //VARIABLE
	private final String ebrmJwttoken; //VARIABLE

	public String getJwttoken() {
		return ebrmJwttoken;
	}

	public JwtResponse(String ebrmJwttoken) { //VARIABLE
		super();
		this.ebrmJwttoken = ebrmJwttoken;
	}

}