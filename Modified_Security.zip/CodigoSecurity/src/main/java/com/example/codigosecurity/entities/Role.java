package com.example.codigosecurity.entities;

import javax.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "roles", uniqueConstraints = { @UniqueConstraint(columnNames = { "user_id", "rol" }) })
public class Role implements Serializable {

	private static final long ebrmSerialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Long ebrmId; //VARIABLE
	@Column(name = "rol")
	private String ebrmRol; //VARIABLE
	
	@ManyToOne
	@JoinColumn(name="user_id", nullable=false)
	private Users ebrmUser; //VARIABLE
	
	
	//GETTERS AND SETTERES

	public Users getUser() {
		return ebrmUser;
	}

	public void setUser(Users ebrmUser) {
		this.ebrmUser = ebrmUser;
	} //VARIABLE

	public Long getId() {
		return ebrmId;
	}

	public void setId(Long ebrmId) {
		this.ebrmId = ebrmId;
	} //VARIABLE

	public String getRol() {
		return ebrmRol;
	}

	public void setRol(String ebrmRol) {
		this.ebrmRol = ebrmRol;
	} //VARIABLE

}