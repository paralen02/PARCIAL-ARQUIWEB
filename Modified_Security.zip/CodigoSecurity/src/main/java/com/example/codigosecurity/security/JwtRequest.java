package com.example.codigosecurity.security;
import java.io.Serializable;

/*
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

//Clase 4
@Data
@AllArgsConstructor
@NoArgsConstructor*/
public class JwtRequest implements Serializable {
	private static final long ebrmSerialVersionUID = 5926468583005150707L; //VARIABLE
	private String ebrmUsername; //VARIABLE
	private String ebrmPassword; //VARIABLE
	public JwtRequest() {
		super();
		// TODO Auto-generated constructor stub
	}
	public JwtRequest(String ebrmUsername, String ebrmPassword) { //VARIABLE
		super();
		this.ebrmUsername = ebrmUsername;
		this.ebrmPassword = ebrmPassword;
	}
	public static long getSerialversionuid() {
		return ebrmSerialVersionUID;
	}
	public String getUsername() {
		return ebrmUsername;
	}
	public String getPassword() {
		return ebrmPassword;
	}
	public void setUsername(String ebrmUsername) {
		this.ebrmUsername = ebrmUsername;
	} //VARIABLE
	public void setPassword(String ebrmPassword) {
		this.ebrmPassword = ebrmPassword;
	} //VARIABLE
}