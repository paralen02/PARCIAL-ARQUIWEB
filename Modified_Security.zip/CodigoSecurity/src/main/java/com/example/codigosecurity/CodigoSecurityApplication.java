package com.example.codigosecurity;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CodigoSecurityApplication {

	public static void main(String[] ebrmArgs) {
		SpringApplication.run(CodigoSecurityApplication.class, ebrmArgs);
	} //VARIABLE(args)

}
