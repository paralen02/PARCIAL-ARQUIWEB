package com.example.codigosecurity.repositories;

import com.example.codigosecurity.entities.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


@Repository
public interface UserRepository extends JpaRepository<Users, Long> {
	public Users findByEbrmUsername(String ebrmUsername); //VARIABLE(username)
	
	//BUSCAR POR NOMBRE
	@Query("select count(ebrmU.ebrmUsername) from Users ebrmU where ebrmU.ebrmUsername =:ebrmUsername")
	public int buscarUsername(@Param("ebrmUsername") String ebrmNombre); //VARIABLE(nombre)
	
	
	//INSERTAR ROLES
	@Transactional
	@Modifying
	@Query(value = "insert into roles (rol, user_id) VALUES (:ebrmRol, :ebrmUser_id)", nativeQuery = true)
	public void insRol(@Param("ebrmRol") String ebrmAuthority, @Param("ebrmUser_id") Long ebrmUser_id); //VARIABLE(authority, user_id)

}