package com.example.codigosecurity.security;

import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.Serializable;

//Clase 7
@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint, Serializable {

    private static final long ebrmSerialVersionUID = -7858869558953243875L; //VARIABLE

    @Override
    public void commence(HttpServletRequest ebrmRequest, HttpServletResponse ebrmResponse,
                         AuthenticationException ebrmAuthException) throws IOException { //VARIABLE(request, response, authException)

        ebrmResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED, "Unauthorized");
    }
}
