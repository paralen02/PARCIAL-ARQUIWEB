package com.example.codigosecurity.entities;

import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

@Entity
@Table(name = "users")
public class Users implements Serializable {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "user_id")
	private Long ebrmId;

	@Column(name="username",length = 30, unique = true)
	private String ebrmUsername;
	@Column(length = 200, name = "password")
	private String ebrmPassword;
	@Column(name = "enabled")
	private Boolean ebrmEnabled;
	@OneToMany(fetch = FetchType.EAGER, cascade = CascadeType.ALL)
	@JoinColumn(name = "user_id")
	@Column(name = "roles")
	private List<Role> ebrmRoles;

	public Long getId() {
		return ebrmId;
	}

	public void setId(Long ebrmId) {
		this.ebrmId = ebrmId;
	} //VARIABLE

	public String getUsername() {
		return ebrmUsername;
	}

	public void setUsername(String ebrmUsername) {
		this.ebrmUsername = ebrmUsername;
	} //VARIABLE

	public String getPassword() {
		return ebrmPassword;
	}

	public void setPassword(String ebrmPassword) {
		this.ebrmPassword = ebrmPassword;
	} //VARIABLE

	public Boolean getEnabled() {
		return ebrmEnabled;
	}

	public void setEnabled(Boolean ebrmEnabled) {
		this.ebrmEnabled = ebrmEnabled;
	} //VARIABLE

	public List<Role> getRoles() {
		return ebrmRoles;
	}

	public void setRoles(List<Role> ebrmRoles) {
		this.ebrmRoles = ebrmRoles;
	} //VARIABLE

}