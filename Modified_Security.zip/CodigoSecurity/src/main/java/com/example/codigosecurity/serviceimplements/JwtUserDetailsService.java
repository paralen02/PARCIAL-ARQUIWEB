package com.example.codigosecurity.serviceimplements;

import com.example.codigosecurity.entities.Users;
import com.example.codigosecurity.repositories.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;


//Clase 2
@Service
public class JwtUserDetailsService implements UserDetailsService {
    @Autowired
    private UserRepository ebrmRepo; //VARIABLE

    @Override
    public UserDetails loadUserByUsername(String ebrmUsername) throws UsernameNotFoundException { //VARIABLE
        Users ebrmUser = ebrmRepo.findByEbrmUsername(ebrmUsername); //VARIABLE

        if(ebrmUser == null) {
            throw new UsernameNotFoundException(String.format("User not exists", ebrmUsername));
        }

        List<GrantedAuthority> ebrmRoles = new ArrayList<>(); //VARIABLE

        ebrmUser.getRoles().forEach(rol -> {
            ebrmRoles.add(new SimpleGrantedAuthority(rol.getRol()));
        });

        UserDetails ebrmUd = new org.springframework.security.core.userdetails.User(ebrmUser.getUsername(), ebrmUser.getPassword(), ebrmUser.getEnabled(), true, true, true, ebrmRoles);
        //VARIABLE
        return ebrmUd;
    }
}