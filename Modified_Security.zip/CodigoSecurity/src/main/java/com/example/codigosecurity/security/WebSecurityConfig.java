package com.example.codigosecurity.security;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.servlet.HandlerExceptionResolver;

//@Profile(value = {"development", "production"})
//Clase S7
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true)
public class WebSecurityConfig {

    @Autowired
    private JwtAuthenticationEntryPoint ebrmJwtAuthenticationEntryPoint; //VARIABLE

    @Autowired
    private UserDetailsService ebrmJwtUserDetailsService; //VARIABLE

    @Autowired
    private JwtRequestFilter ebrmJwtRequestFilter; //VARIABLE

    @Autowired
    @Qualifier("handlerExceptionResolver")
    private HandlerExceptionResolver ebrmExceptionResolver; //VARIABLE

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration ebrmAuthenticationConfiguration) throws Exception { //VARIABLE
        return ebrmAuthenticationConfiguration.getAuthenticationManager();
    }

    @Bean
    public static PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder ebrmAuth) throws Exception { //VARIABLE
        ebrmAuth.userDetailsService(ebrmJwtUserDetailsService).passwordEncoder(passwordEncoder()); //VARIABLE
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity ebrmHttpSecurity) throws Exception { //VARIABLE
        ebrmHttpSecurity
                .csrf().disable()
                .authorizeRequests()
                .antMatchers("/authenticate").permitAll() //.hasAuthority("ADMIN")
                .anyRequest().authenticated()
                .and()
                .exceptionHandling().authenticationEntryPoint(ebrmJwtAuthenticationEntryPoint)
                .and()
                .formLogin().disable()
                .sessionManagement()
                .sessionCreationPolicy(SessionCreationPolicy.STATELESS);

        ebrmHttpSecurity.addFilterBefore(ebrmJwtRequestFilter, UsernamePasswordAuthenticationFilter.class); //VARIABLE

        return ebrmHttpSecurity.build();
    }
}
