package com.example.codigosecurity.controllers;

import com.example.codigosecurity.security.JwtRequest;
import com.example.codigosecurity.security.JwtResponse;
import com.example.codigosecurity.security.JwtTokenUtil;
import com.example.codigosecurity.serviceimplements.JwtUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


//Clase 3
@RestController
@CrossOrigin
public class JwtAuthenticationController {
	@Autowired
	private AuthenticationManager ebrmAuthenticationManager; //VARIABLE
	@Autowired
	private JwtTokenUtil ebrmJwtTokenUtil; //VARIABLE
	@Autowired
	private JwtUserDetailsService ebrmUserDetailsService; //VARIABLE
	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody JwtRequest ebrmAuthenticationRequest) throws Exception { //VARIABLE (authenticationRequest)
		authenticate(ebrmAuthenticationRequest.getUsername(), ebrmAuthenticationRequest.getPassword());
		final UserDetails ebrmUserDetails = ebrmUserDetailsService.loadUserByUsername(ebrmAuthenticationRequest.getUsername()); //VARIABLE
		final String ebrmToken = ebrmJwtTokenUtil.generateToken(ebrmUserDetails); //VARIABLE
		return ResponseEntity.ok(new JwtResponse(ebrmToken));
	}
	private void authenticate(String ebrmUsername, String ebrmPassword) throws Exception { //VARIABLE
		try {
			ebrmAuthenticationManager.authenticate(new UsernamePasswordAuthenticationToken(ebrmUsername, ebrmPassword));
		} catch (DisabledException ebrmE) {
			throw new Exception("USER_DISABLED", ebrmE);
		} catch (BadCredentialsException ebrmE) {
			throw new Exception("INVALID_CREDENTIALS", ebrmE);
		}
	}
}