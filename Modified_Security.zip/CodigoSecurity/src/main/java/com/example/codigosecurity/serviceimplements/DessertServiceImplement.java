package com.example.codigosecurity.serviceimplements;

import com.example.codigosecurity.entities.Dessert;
import com.example.codigosecurity.repositories.IDessertRepository;
import com.example.codigosecurity.serviceinterfaces.IDessertService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;

@Service
public class DessertServiceImplement implements IDessertService {
    @Autowired
    private IDessertRepository dR;

    @Override
    public void insert(Dessert dessert) {
        dR.save(dessert);
    }

    @Override
    public List<Dessert> list() {
        return dR.findAll();
    }

    @Override
    public void delete(int idDessert) {
        dR.deleteById(idDessert);
    }

    @Override
    public Dessert listarId(int idDessert) {
        return dR.findById(idDessert).orElse(new Dessert());
    }

    @Override
    public List<Dessert> findByDueDateDessert(LocalDate dueDateDessert) {
        return dR.findByDueDateDessert(dueDateDessert);
    }


}
